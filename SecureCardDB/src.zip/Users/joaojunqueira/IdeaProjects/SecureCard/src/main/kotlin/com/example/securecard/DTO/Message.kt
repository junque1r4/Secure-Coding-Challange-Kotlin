package com.example.securecard.DTO

class Message(public val message: String) {
}