package com.example.securecard

import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class SecureCardApplicationTests {

    @Test
    fun contextLoads() {
    }

}
